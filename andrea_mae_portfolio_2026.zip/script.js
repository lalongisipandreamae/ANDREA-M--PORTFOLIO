document.addEventListener("DOMContentLoaded", () => {
  const menuToggle = document.getElementById("menuToggle");
  const navLinks = document.getElementById("navLinks");

  if (menuToggle && navLinks) {
    menuToggle.addEventListener("click", () => {
      navLinks.classList.toggle("open");
    });

    navLinks.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => navLinks.classList.remove("open"));
    });
  }

  const copyBtn = document.getElementById("copyEmailBtn");
  if (copyBtn) {
    copyBtn.addEventListener("click", () => {
      navigator.clipboard.writeText("lalongisipandreamae@gmail.com").then(() => {
        const originalText = copyBtn.textContent;
        copyBtn.textContent = "Copied!";
        setTimeout(() => {
          copyBtn.textContent = originalText;
        }, 2000);
      });
    });
  }

  const certificateData = {
    csharp: {
      tag: "01 / VERIFIED MILESTONE",
      title: "C# CERTIFICATE",
      description:
        "Awarded in recognition of completing foundational C# programming concepts, syntax, control structures, and introductory object-oriented problem solving.",
      skills: ["C# Syntax", "Variables & Data Types", "Control Flow", "Problem-Solving"]
    },
    clang: {
      tag: "02 / VERIFIED MILESTONE",
      title: "C LANGUAGE CERTIFICATE",
      description:
        "Awarded in recognition of mastering core C programming fundamentals, algorithmic logic, structured functions, and basic troubleshooting.",
      skills: ["C Fundamentals", "Loops & Conditions", "Functions", "Algorithmic Thinking"]
    }
  };

  const modal = document.getElementById("certModal");
  const closeModal = document.getElementById("closeModal");
  const modalTag = document.getElementById("modalTag");
  const modalTitle = document.getElementById("modalTitle");
  const modalDesc = document.getElementById("modalDesc");
  const modalSkills = document.getElementById("modalSkills");

  document.querySelectorAll(".cert-card").forEach((card) => {
    card.addEventListener("click", () => {
      const key = card.getAttribute("data-cert");
      const info = certificateData[key];
      if (!info) return;

      modalTag.textContent = info.tag;
      modalTitle.textContent = info.title;
      modalDesc.textContent = info.description;
      modalSkills.innerHTML = info.skills.map((s) => `<span>${s}</span>`).join("");

      modal.classList.add("active");
      modal.setAttribute("aria-hidden", "false");
    });
  });

  if (closeModal && modal) {
    closeModal.addEventListener("click", () => {
      modal.classList.remove("active");
      modal.setAttribute("aria-hidden", "true");
    });

    modal.addEventListener("click", (e) => {
      if (e.target === modal) {
        modal.classList.remove("active");
        modal.setAttribute("aria-hidden", "true");
      }
    });
  }

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.12 }
  );

  document.querySelectorAll(".reveal").forEach((el) => observer.observe(el));
});
